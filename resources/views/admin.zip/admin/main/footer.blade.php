<footer class="main-footer">
  <!-- To the right -->
  <div class="float-right d-none d-sm-inline">
    <b>Version</b> 1.0.0
  </div>
  <!-- Default to the left -->
  <strong>Copyright © 2021 @if(Date('Y') != 2021) - {{ Date('Y') }}@endif <a href="https://www.techware.com.np" target="_blank">Techware Pvt. Ltd.</a>.</strong>
	All rights reserved.
</footer>